import { neon } from '@netlify/neon';

export const handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    const data = JSON.parse(event.body || "{}");

    // Basic Validation
    if (!data.projectId || !data.auditor) {
      return { 
        statusCode: 400, 
        body: JSON.stringify({ ok: false, error: "Missing projectId or auditor" }) 
      };
    }

    const sql = neon(process.env.NETLIFY_DATABASE_URL);
    
    // Create a unique ID manually (since schema uses TEXT id, not SERIAL)
    const id = `audit-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
    
    // Findings array must be stringified for JSONB column
    const findingsJson = JSON.stringify(data.findings || []);

    // Insert into DB
    // We map the input data to snake_case columns
    const [newAudit] = await sql`
      INSERT INTO audits (
        id, 
        project_id, 
        site_name, 
        auditor, 
        status, 
        findings, 
        created_at, 
        updated_at
      ) VALUES (
        ${id}, 
        ${data.projectId}, 
        ${data.siteName}, 
        ${data.auditor}, 
        ${data.status || 'Open'}, 
        ${findingsJson}::jsonb, 
        NOW(), 
        NOW()
      )
      RETURNING 
        id, 
        project_id as "projectId", 
        site_name as "siteName", 
        auditor, 
        status, 
        findings, 
        created_at as "createdAt", 
        updated_at as "updatedAt"
    `;

    return {
      statusCode: 201,
      body: JSON.stringify({ ok: true, audit: newAudit }),
    };
  } catch (error) {
    console.error("createAudit error:", error);
    return { 
      statusCode: 500, 
      body: JSON.stringify({ ok: false, error: error.message }) 
    };
  }
};