mport { neon } from '@netlify/neon';

export const handler = async (event) => {
  if (event.httpMethod !== "GET") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    const sql = neon(process.env.NETLIFY_DATABASE_URL);
    const projectId = event.queryStringParameters?.projectId;

    let rows;

    // We select with aliases so the frontend receives camelCase keys (e.g., projectId)
    // instead of snake_case database keys (project_id).

    if (projectId) {
      // Optimized: Filter in the database query if a project ID is provided
      rows = await sql`
        SELECT 
          id, 
          project_id as "projectId", 
          site_name as "siteName", 
          auditor, 
          status, 
          findings, 
          created_at as "createdAt", 
          updated_at as "updatedAt"
        FROM audits
        WHERE project_id = ${projectId}
        ORDER BY created_at DESC
      `;
    } else {
      // Fetch all if no filter provided
      rows = await sql`
        SELECT 
          id, 
          project_id as "projectId", 
          site_name as "siteName", 
          auditor, 
          status, 
          findings, 
          created_at as "createdAt", 
          updated_at as "updatedAt"
        FROM audits
        ORDER BY created_at DESC
      `;
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ ok: true, audits: rows }),
    };
  } catch (error) {
    console.error("listAudits error:", error);
    return { statusCode: 500, body: JSON.stringify({ ok: false, error: error.message }) };
  }
};