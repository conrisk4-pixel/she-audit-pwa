const fetch = require("node-fetch");

exports.handler = async function(event) {
  try {
    const body = JSON.parse(event.body);
    const { NEON_API_KEY, NEON_SQL_ENDPOINT } = process.env;

    if (!NEON_API_KEY || !NEON_SQL_ENDPOINT) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "Missing Neon credentials." }),
      };
    }

    const result = await fetch(NEON_SQL_ENDPOINT, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${NEON_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        sql: \`
          INSERT INTO audits (id, project, site, score, findings, uploaded_by, date)
          VALUES (
            '\${body.id}', '\${body.project}', '\${body.site}', \${body.score},
            '\${body.findings}', '\${body.uploaded_by}', '\${body.date}'
          )
          ON CONFLICT (id) DO UPDATE SET
            project = EXCLUDED.project,
            site = EXCLUDED.site,
            score = EXCLUDED.score,
            findings = EXCLUDED.findings,
            uploaded_by = EXCLUDED.uploaded_by,
            date = EXCLUDED.date;
        \`
      })
    });

    const data = await result.json();
    return {
      statusCode: 200,
      body: JSON.stringify(data),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
